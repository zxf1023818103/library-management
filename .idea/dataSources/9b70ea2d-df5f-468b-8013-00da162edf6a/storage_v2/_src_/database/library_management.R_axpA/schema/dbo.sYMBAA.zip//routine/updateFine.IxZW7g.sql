create procedure updateFine @studentId int as
    update Student set fine = t.fine from (select sum((datediff(day, beginDate, getdate()) - maxBorrowPeriodDay) * finePerDay) as fine from Student join BorrowRecord BR on Student.id = BR.studentId where datediff(day, beginDate, getdate()) > maxBorrowPeriodDay and studentId = @studentId group by studentId) as t where id = @studentId;
go

