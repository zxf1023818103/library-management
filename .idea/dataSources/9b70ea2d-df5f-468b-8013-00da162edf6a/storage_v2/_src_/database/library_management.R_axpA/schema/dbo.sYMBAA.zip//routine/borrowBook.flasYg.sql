create procedure borrowBook @studentId int, @bookId int as
begin
    declare @fine smallmoney;
    select @fine = fine from Student where id = @studentId;
    if @fine <> 0
        --- 未缴清罚款
        return -1;
    declare @borrowedNumber int, @maxBorrowedNumber int;
    select @borrowedNumber = count(*) from BorrowRecord where studentId = @studentId and returned = 0;
    select @maxBorrowedNumber = maxBorrowNumber from Student where id = @studentId;
    if @borrowedNumber > @maxBorrowedNumber
        --- 超过最大借阅数量
        return -2;
    if not exists(select * from Book where id = @bookId)
        --- 图书不存在
        return -4;
    if exists(select * from BorrowRecord where bookId = @bookId and returned = 0)
        --- 该书已借出
        return -3;
    insert into BorrowRecord (studentId, bookId) values (@studentId, @bookId);
    return 0;
end;
go

