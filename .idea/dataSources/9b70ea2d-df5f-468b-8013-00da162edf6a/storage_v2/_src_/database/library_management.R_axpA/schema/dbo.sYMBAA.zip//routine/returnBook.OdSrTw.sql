create procedure returnBook @bookId int, @fine smallmoney output as
begin
    set @fine = 0;
    declare @studentId int;
    select @studentId = studentId from BorrowRecord where bookId = @bookId and returned = 0;
    if @studentId is null
        --- 借阅记录不存在
        return -4;
    declare @borrowedDay int;
    declare @maxBorrowPeriodDay int;
    select @borrowedDay = datediff(day, beginDate, getdate()) from BorrowRecord where studentId = @studentId and id = @bookId;
    select @maxBorrowPeriodDay = maxBorrowPeriodDay from Student where id = @studentId;
    update BorrowRecord set returned = 1 where studentId = @studentId and id = @bookId and returned = 0;
    if @borrowedDay > @maxBorrowPeriodDay
    begin
        select @fine = finePerDay * @borrowedDay from Student where id = @studentId;
        update Student set fine = @fine where id = @studentId;
        --- 产生了罚款
        return -5;
    end;
    return 0;
end;
go

